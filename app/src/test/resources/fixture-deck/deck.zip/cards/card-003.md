# Question

Card 3 front — what is the capital of country 3?

![img](media/card-003.png)

---

# Answer

Capital City 3

Gruppe: Test / CI.Fixture
