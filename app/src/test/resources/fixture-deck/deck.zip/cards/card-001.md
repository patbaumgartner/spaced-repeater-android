# Question

Card 1 front — what is the capital of country 1?

![img](media/card-001.png)

---

# Answer

Capital City 1

Gruppe: Test / CI.Fixture
