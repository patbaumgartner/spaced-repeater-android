# Question

Card 2 front — what is the capital of country 2?

![img](media/card-002.png)

---

# Answer

Capital City 2

Gruppe: Test / CI.Fixture
